from __future__ import annotations

import importlib.util
from pathlib import Path
from types import SimpleNamespace
import pytest
from PIL import Image


@pytest.fixture
def evaluation():
    root = Path(__file__).resolve().parents[1]
    spec = importlib.util.spec_from_file_location(
        "prompt_study_eval", root / "scripts/eval/eval_qwen21_joint_pilot.py"
    )
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def test_study_generation_keeps_A_and_original_target_size(evaluation):
    a = Image.new("RGB", (608, 1088))
    args = SimpleNamespace(
        resolution="native",
        align_mode="native",
        steps=30,
        use_kv_cache=True,
    )
    kw = evaluation.generation_arguments(
        a,
        args,
        prompt="Raise both arms",
        generator=None,
        target_size=(736, 1024),
    )
    assert kw["image"] == [a]
    assert kw["prompt"] == "Raise both arms"
    assert (kw["width"], kw["height"]) == (736, 1024)
    assert not {"latents", "target", "gt_image"} & kw.keys()


def test_eval_arguments_study_mode(evaluation, monkeypatch):
    import sys

    argv = [
        "eval.py",
        "--checkpoint", "checkpoint.pt",
        "--pairs", "pairs.jsonl",
        "--features", "features",
        "--cache", "cache",
        "--output", "output",
        "--resolution", "native",
        "--align-mode", "native",
        "--lora", "head.safetensors",
        "--study-lock", "lock.json",
        "--arm", "head_pb",
        "--prompt-manifest", "prompts.jsonl",
        "--study-step", "128",
        "--study-split", "val",
    ]
    monkeypatch.setattr(sys, "argv", argv)
    args = evaluation.arguments()
    assert args.study_lock == Path("lock.json")
    assert args.arm == "head_pb"
    assert args.study_step == 128
    assert args.study_split == "val"
    assert args.label == "head_pb_step_128"


def test_crop_normalized_native_resolutions(evaluation):
    import numpy as np

    # Test 604x1080
    img1 = Image.new("RGB", (604, 1080), color=(100, 150, 200))
    box = [0.2, 0.1, 0.4, 0.3]
    cropped1, pixels1 = evaluation.crop_normalized(img1, box, side=128)
    assert cropped1 is not None
    assert cropped1.size == (128, 128)
    assert pixels1[0] == int(np.floor(0.2 * 604))
    assert pixels1[1] == int(np.floor(0.1 * 1080))
    assert pixels1[2] == int(np.ceil(0.4 * 604))
    assert pixels1[3] == int(np.ceil(0.3 * 1080))

    # Test 736x1024
    img2 = Image.new("RGB", (736, 1024), color=(50, 80, 110))
    cropped2, pixels2 = evaluation.crop_normalized(img2, box, side=128)
    assert cropped2 is not None
    assert pixels2[0] == int(np.floor(0.2 * 736))
    assert pixels2[1] == int(np.floor(0.1 * 1024))
    assert pixels2[2] == int(np.ceil(0.4 * 736))
    assert pixels2[3] == int(np.ceil(0.3 * 1024))


def test_compute_bg_l1_background_preservation(evaluation):
    src = Image.new("RGB", (100, 100), color=(200, 200, 200))
    # Identical output: bg L1 is 0.0
    mask_a = Image.new("L", (100, 100), color=0)  # no foreground
    l1, reason = evaluation.compute_bg_l1(src, src, mask_a=mask_a)
    assert reason is None
    assert l1 == pytest.approx(0.0)

    # Different background
    gen = Image.new("RGB", (100, 100), color=(100, 100, 100))
    l1_diff, reason = evaluation.compute_bg_l1(src, gen, mask_a=mask_a)
    assert reason is None
    assert l1_diff == pytest.approx(100.0 / 255.0, abs=1e-3)


@pytest.mark.parametrize("extra", [
    ["--study-step", "129"], ["--resolution", "512"], ["--steps", "29"],
    ["--with-hand"], ["--face-strength", "0"], ["--geometry-strength", "0"],
    ["--stage", "hotload"], ["--variant", "BFSBody"], ["--seed", "44"],
    ["--no-use-kv-cache"], ["--progress-mode", "sigma"],
])
def test_study_eval_rejects_protocol_drift(evaluation, extra):
    argv = ["--checkpoint", "ckpt", "--pairs", "pairs", "--features", "features",
            "--cache", "cache", "--output", "out", "--study-lock", "lock",
            "--arm", "qwen_p0", "--prompt-manifest", "prompts", "--study-step", "128",
            "--study-split", "val", "--resolution", "native", "--align-mode", "native"]
    with pytest.raises(SystemExit):
        evaluation.arguments(argv + extra)


def test_artifacts_preserve_both_target_hand_rois(evaluation, tmp_path):
    image = Image.new("RGB", (604, 1080), "blue")
    image.paste("red", (0, 0, 302, 1080))
    files = evaluation.save_case_artifacts(tmp_path, "hands", source=image, target=image,
        generated=image, normal=None, pose=None, source_box=None, target_box=None,
        target_lh_box=[0, 0, .4, 1], target_rh_box=[.6, 0, 1, 1])
    assert Image.open(tmp_path / files["hand_left_output"]).getpixel((128, 128)) == (255, 0, 0)
    assert Image.open(tmp_path / files["hand_right_output"]).getpixel((128, 128)) == (0, 0, 255)


def test_cross_person_flag_prohibits_target_pixel_metric(evaluation, monkeypatch, tmp_path):
    import json
    import numpy as np
    import src.evaluation.joint_pilot_metrics as metrics
    detector = SimpleNamespace(detect=lambda image: ([], []))
    monkeypatch.setattr(metrics, "IdentityMetric", lambda root: SimpleNamespace(det=detector))
    monkeypatch.setattr(metrics, "PoseMetric", lambda root: SimpleNamespace())
    Image.new("RGB", (64, 64), "white").save(tmp_path / "source.png")
    Image.new("RGB", (64, 64), "black").save(tmp_path / "target.png")
    Image.new("L", (64, 64), 0).save(tmp_path / "mask.png")
    row = dict(pair_index=0, image_stem="case", status="complete", image="source.png",
               source="source.png", target="target.png", target_mask="mask.png",
               metadata={"cross_person": True}, resolution="native")
    (tmp_path / "per_sample.jsonl").write_text(json.dumps(row) + "\n")
    score = evaluation.score_saved_outputs(tmp_path)[0]
    assert score["pixel_l1_GT"] is None
    assert score["bg_l1_A"] == 0


def test_tiktok_metadata_preserves_geometry_and_video_groups():
    from src.pose_control.qwen21_full.data_runtime import pair_metadata
    row = dict(pair_id="cross", sequence_id="B", source_appearance="A", target_appearance="B",
               source_stem="1", target_stem="2", source_rgb="a.png", target_rgb="b.png",
               target_dwpose_json="b.json", source_video_group="group-a", target_video_group="group-b")
    meta = pair_metadata(row)
    assert meta["target_dwpose_json"] == "b.json"
    assert meta["source_video_group"] == "group-a"
    assert meta["target_video_group"] == "group-b"
    assert meta["sequence_id"] == "B"


@pytest.mark.parametrize('field,wrong', [
    ('arm', 'head_pb'), ('step', 256), ('study_schema', 'other'),
    ('study_lock_sha256', 'other'), ('joint_initialization_sha256', 'other'),
    ('model_revision', 'other'),
])
def test_study_checkpoint_rejects_mismatched_identity(evaluation, monkeypatch, tmp_path, field, wrong):
    from src.pose_control.qwen21_full.prompt_study import protocol
    from src.pose_control.qwen21_full.qwen_runtime import MODEL_REVISION
    args = SimpleNamespace(arm='qwen_p0', study_step=128, study_lock=tmp_path / 'lock.json',
        model=tmp_path / 'model', features=tmp_path / 'data/face_cache', lora=None)
    args.study_lock.write_text('{}')
    signature = dict(schema=protocol.SCHEMA, study_schema=protocol.SCHEMA, arm='qwen_p0', protocol='p0',
        max_updates=1024, initial_history_steps=256, model_revision=MODEL_REVISION,
        model=str(args.model.resolve()), model_manifest_sha256='model-hash', lora_sha256=None,
        strength=1, study_lock_sha256=evaluation.digest_file(args.study_lock),
        instruction_sha256=protocol.text_sha256(protocol.P0_PROMPT), face_assets_sha256='face-hash',
        resolution='native', align_mode='native', preprocessing='native_v1', with_hand=False)
    checkpoint = dict(arm='qwen_p0', step=128, study_schema=protocol.SCHEMA,
        study_lock_sha256=signature['study_lock_sha256'], joint_initialization_sha256=protocol.INIT_SHA256,
        model_revision=MODEL_REVISION, joint_signature=signature, next_update_index=128,
        sample_order=protocol.make_order()[:128] if hasattr(protocol, 'make_order') else list(range(128)))
    checkpoint[field] = wrong
    lock = {'initial_checkpoint_sha256': protocol.INIT_SHA256,
            'artifacts': {'model': {'manifest_sha256': 'model-hash'}}, 'epoch_order': list(range(128))}
    bank = SimpleNamespace(records={'one': {'instruction_sha256': '', 'instruction_version': 'none'}}, protocol='p0')
    monkeypatch.setattr(protocol, 'validate_study_binding', lambda *a, **kw: None, raising=False)
    monkeypatch.setattr(evaluation, 'study_asset_signature', lambda *a, **kw: {'face_assets_sha256': 'face-hash'}, raising=False)
    with pytest.raises(ValueError):
        evaluation.validate_study_checkpoint(args, lock, checkpoint, bank)


@pytest.fixture
def signed_checkpoint(evaluation, monkeypatch, tmp_path):
    from src.pose_control.qwen21_full.prompt_study import protocol
    from src.pose_control.qwen21_full.prompt_study.sampling import make_order
    from src.pose_control.qwen21_full.qwen_runtime import MODEL_REVISION
    run = tmp_path / 'run'
    (run / 'data').mkdir(parents=True)
    (run / 'prompts/p0').mkdir(parents=True)
    (run / 'data/lock.json').write_text('{}')
    (run / 'prompts/p0/train.jsonl').write_text('train-prompt-records')
    (run / 'prompts/instruction_v1.json').write_text('{}')
    args = SimpleNamespace(arm='qwen_p0', study_step=128, study_lock=run / 'data/lock.json',
        model=tmp_path / 'model', features=run / 'data/face_cache', lora=None)
    lock = {'initial_checkpoint_sha256': protocol.INIT_SHA256,
            'artifacts': {'model': {'manifest_sha256': 'model-hash'}}, 'epoch_order': make_order()}
    bank = SimpleNamespace(protocol='p0', records={'one': {'instruction_sha256': '', 'instruction_version': 'none'}})
    signature = dict(schema=protocol.SCHEMA, study_schema=protocol.SCHEMA, arm='qwen_p0', protocol='p0',
        max_updates=1024, initial_history_steps=256, model_revision=MODEL_REVISION,
        model=str(args.model.resolve()), model_manifest_sha256='model-hash', lora_sha256=None, strength=1,
        study_lock_sha256=evaluation.digest_file(args.study_lock), resolution='native', align_mode='native',
        preprocessing='native_v1', with_hand=False, face_assets_sha256='face-hash',
        instruction_sha256=evaluation.digest_file(run / 'prompts/instruction_v1.json'), instruction_version='none',
        prompt_instruction_sha256=protocol.text_sha256(protocol.P0_PROMPT),
        prompt_manifest_sha256=evaluation.digest_file(run / 'prompts/p0/train.jsonl'))
    signature.update(evaluation.study_code_signature())
    checkpoint = dict(arm=args.arm, step=128, study_schema=protocol.SCHEMA,
        study_lock_sha256=signature['study_lock_sha256'], joint_initialization_sha256=protocol.INIT_SHA256,
        model_revision=MODEL_REVISION, joint_signature=signature, next_update_index=128,
        sample_order=make_order()[:128])
    monkeypatch.setattr(protocol, 'validate_study_binding', lambda *a, **kw: None)
    monkeypatch.setattr(evaluation, 'study_asset_signature', lambda *a, **kw: {'face_assets_sha256': 'face-hash'})
    return args, lock, checkpoint, bank


def test_study_accepts_valid_checkpoint_without_matching_val_and_train_manifest(evaluation, signed_checkpoint):
    args, lock, checkpoint, bank = signed_checkpoint
    args.prompt_manifest = args.study_lock.parent.parent / 'prompts/p0/val.jsonl'
    args.prompt_manifest.write_text('different-val-records')
    evaluation.validate_study_checkpoint(args, lock, checkpoint, bank)


@pytest.mark.parametrize('field,wrong', [
    ('arm', 'head_p0'), ('protocol', 'pb'), ('model_manifest_sha256', 'other'),
    ('lora_sha256', 'other'), ('instruction_sha256', 'other'), ('face_assets_sha256', 'other'),
    ('prompt_manifest_sha256', 'other'), ('runtime_code_sha256', {}), ('with_hand', True),
])
def test_study_rejects_changed_training_signature(evaluation, signed_checkpoint, field, wrong):
    args, lock, checkpoint, bank = signed_checkpoint
    checkpoint['joint_signature'][field] = wrong
    with pytest.raises(ValueError, match='signature|manifest'):
        evaluation.validate_study_checkpoint(args, lock, checkpoint, bank)

