# reports 目录说明

**路径**: `scripts/reports`

## 1. 目录定位与职责

实验报告汇总、图表美化与面板合成脚本目录。

**工程定位**: 负责生成四联图对比面板、指标柱状图以及汇报用 Word/HTML 文档配图。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 5 个文件
- **文件类型统计**: .md: 1个, .py: 4个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `build_qwen21_joint_pilot_report.py` | 该模块下实现/记录文件 |
| `build_qwen21_joint_pilot_review_sheets.py` | 该模块下实现/记录文件 |
| `build_qwen21_pei2i_study_report.py` | 该模块下实现/记录文件 |
| `summarize_qwen21_joint_pilot.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
