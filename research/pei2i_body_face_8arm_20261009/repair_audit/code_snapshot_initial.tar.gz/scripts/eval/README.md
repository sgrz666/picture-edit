# eval 目录说明

**路径**: `scripts/eval`

## 1. 目录定位与职责

模型评测与推理验证脚本目录。

**工程定位**: 包含单/双阶段模型推理、多模型消融对照与定量指标自动评估脚本。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 5 个文件
- **文件类型统计**: .md: 1个, .py: 4个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `bfs_compare.py` | 该模块下实现/记录文件 |
| `build_bfs_comparison_report.py` | 该模块下实现/记录文件 |
| `eval_qwen21_joint_pilot.py` | 该模块下实现/记录文件 |
| `summarize_bfs_comparison.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
