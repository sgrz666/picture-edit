# data 目录说明

**路径**: `scripts/data`

## 1. 目录定位与职责

数据处理、预计算与缓存构建脚本目录。

**工程定位**: 包含 iPER/TikTok 划分清洗、SMPL-X 条件离线预计算与缓存生成脚本。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 5 个文件
- **文件类型统计**: .md: 1个, .py: 4个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `convert_face_supervision_to_native.py` | 该模块下实现/记录文件 |
| `prepare_qwen21_joint_pilot.py` | 该模块下实现/记录文件 |
| `prepare_qwen21_prompt_study.py` | 该模块下实现/记录文件 |
| `prepare_qwen21_prompt_study_faces.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
