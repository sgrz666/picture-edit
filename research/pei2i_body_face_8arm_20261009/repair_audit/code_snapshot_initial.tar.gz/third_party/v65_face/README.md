# v65_face 目录说明

**路径**: `third_party/v65_face`

## 1. 目录定位与职责

V6.5 人脸模块外部依赖与接口包装目录。

**工程定位**: 集成 MCLD、StableAnimator、Visual Persona 及 X-Dyna 等开源人脸保持技术。

## 2. 目录结构与内容汇总

### 子文件夹

- **`licenses/`**: 该子目录下的专门功能模块或产物。

### 文件概览

- **文件总数**: 7 个文件
- **文件类型统计**: .md: 2个, .py: 5个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `UPSTREAM_SOURCES.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `mcld.py` | 该模块下实现/记录文件 |
| `stableanimator.py` | 该模块下实现/记录文件 |
| `visual_persona.py` | 该模块下实现/记录文件 |
| `xdyna.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
