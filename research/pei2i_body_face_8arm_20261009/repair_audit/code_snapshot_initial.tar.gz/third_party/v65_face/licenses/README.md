# licenses 目录说明

**路径**: `third_party/v65_face/licenses`

## 1. 目录定位与职责

第三方人脸模块开源许可证目录。

**工程定位**: 保存 StableAnimator (MIT) 及 X-Dyna (Apache 2.0) 许可证声明。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 3 个文件
- **文件类型统计**: .md: 1个, .txt: 2个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `STABLEANIMATOR-MIT.txt` | 该模块下实现/记录文件 |
| `X-DYNA-APACHE-2.0.txt` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
