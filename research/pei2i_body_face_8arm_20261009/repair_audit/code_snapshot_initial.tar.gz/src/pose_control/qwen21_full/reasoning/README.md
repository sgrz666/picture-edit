# reasoning 目录说明

**路径**: `src/pose_control/qwen21_full/reasoning`

## 1. 目录定位与职责

Qwen 2.1 Full 空间几何推理核心模块目录。

**工程定位**: 包含单人几何推理、双人空间关系注意力机制、接触推理网络及外观特征空间桥接。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 10 个文件
- **文件类型统计**: .md: 1个, .py: 9个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `blocks.py` | 该模块下实现/记录文件 |
| `config.py` | 该模块下实现/记录文件 |
| `contact.py` | 该模块下实现/记录文件 |
| `cross_person.py` | 该模块下实现/记录文件 |
| `fusion.py` | 该模块下实现/记录文件 |
| `person_geometry.py` | 该模块下实现/记录文件 |
| `reasoner.py` | 该模块下实现/记录文件 |
| `state.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
