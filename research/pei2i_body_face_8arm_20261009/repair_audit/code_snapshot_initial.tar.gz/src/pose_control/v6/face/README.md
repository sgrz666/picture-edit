# face 目录说明

**路径**: `src/pose_control/v6/face`

## 1. 目录定位与职责

DeepGen V6.5 人脸增强模块目录。

**工程定位**: 负责面部关键点编码、表情注入及人脸身份保持特征融合。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 10 个文件
- **文件类型统计**: .md: 1个, .py: 9个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `adapter.py` | 该模块下实现/记录文件 |
| `conditions.py` | 条件数据结构定义（包含目标法线、姿态热图、部位掩码与任务 Token） |
| `content_encoder.py` | 该模块下实现/记录文件 |
| `geometry.py` | 该模块下实现/记录文件 |
| `iper_dataset.py` | iPER 数据集专用读取管道，支持源图/目标图配对与几何条件加载 |
| `preparer.py` | 该模块下实现/记录文件 |
| `resampler.py` | 该模块下实现/记录文件 |
| `spatial.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
