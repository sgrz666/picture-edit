# detail 目录说明

**路径**: `src/pose_control/v6/detail`

## 1. 目录定位与职责

DeepGen V6 细节控制分支模块目录。

**工程定位**: 提供局部细节特征处理与辅助残差计算。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 9 个文件
- **文件类型统计**: .md: 1个, .py: 8个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `binder.py` | 该模块下实现/记录文件 |
| `conditions.py` | 条件数据结构定义（包含目标法线、姿态热图、部位掩码与任务 Token） |
| `dwpose_evaluator.py` | 该模块下实现/记录文件 |
| `encoders.py` | 该模块下实现/记录文件 |
| `hand.py` | 该模块下实现/记录文件 |
| `metrics.py` | 图像质量定量评价指标实现（PSNR、SSIM、LPIPS、FID 等） |
| `preparer.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
