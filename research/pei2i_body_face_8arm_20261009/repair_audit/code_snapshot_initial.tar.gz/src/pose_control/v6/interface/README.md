# interface 目录说明

**路径**: `src/pose_control/v6/interface`

## 1. 目录定位与职责

DeepGen V6 控制器基础接口目录。

**工程定位**: 规范适配器状态字典、前向传参与输出特征结构。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 5 个文件
- **文件类型统计**: .md: 1个, .py: 4个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `deepgen_interface.py` | 该模块下实现/记录文件 |
| `outputs.py` | 该模块下实现/记录文件 |
| `strength.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
