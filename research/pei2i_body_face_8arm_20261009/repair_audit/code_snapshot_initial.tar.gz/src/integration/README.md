# integration 目录说明

**路径**: `src/integration`

## 1. 目录定位与职责

扩散模型与 DiT 生成管线集成目录。

**工程定位**: 负责将外挂姿态控制器与 Diffusers / DiT Pipeline 挂接，实现端到端采样与去噪控制。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 3 个文件
- **文件类型统计**: .md: 1个, .py: 2个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `champ_deepgen.py` | 该模块下实现/记录文件 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
