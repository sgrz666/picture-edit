# adapter 目录说明

**路径**: `src/adapter`

## 1. 目录定位与职责

早期 CNN 姿态适配器模块目录，包含 `PoseConditionAdapter`。

**工程定位**: 实现零卷积初始化的 8 通道姿态条件注入网络，作为早期显存基线与轻量控制原型。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 3 个文件
- **文件类型统计**: .md: 1个, .py: 2个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `pose_adapter.py` | 早期 CNN 姿态适配器 `PoseConditionAdapter` 实现，利用零卷积初始化向 DiT 注入 8 通道控制特征 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
