# data 目录说明

**路径**: `src/data`

## 1. 目录定位与职责

PyTorch 数据集与数据加载器目录，支持 iPER、TikTok、Hi4D 等数据集。

**工程定位**: 负责配对样本读取、几何条件动态打包（Condition Bundle）及多分辨率图像张量预处理。

## 2. 目录结构与内容汇总

### 文件概览

- **文件总数**: 7 个文件
- **文件类型统计**: .md: 1个, .py: 6个

| 文件名 | 说明 |
|---|---|
| `README.md` | 该模块下实现/记录文件 |
| `__init__.py` | 该模块下实现/记录文件 |
| `hi4d_qwen21_dataset.py` | 该模块下实现/记录文件 |
| `iper_dataset.py` | iPER 数据集专用读取管道，支持源图/目标图配对与几何条件加载 |
| `iper_detail_dataset.py` | 该模块下实现/记录文件 |
| `letterbox.py` | 该模块下实现/记录文件 |
| `tiktok_dataset.py` | TikTok 数据集专用读取管道，支持单人舞蹈视频帧对与关键点坐标对齐 |

## 3. 使用与关联说明

- 更多全局架构说明与模型演进路线请参阅根目录 [README.md](../../README.md) 或 [docs/PROJECT_STRUCTURE_20261003.md](../../docs/PROJECT_STRUCTURE_20261003.md)。
- 本目录下的所有文件均遵循项目统一的代码风格与数据管理规范。
